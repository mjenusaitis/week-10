var highlighter = document.getElementById("highlighter");
var nextOne = document.querySelectorAll("div img");
//console.log(imagesArray);

imagesArray.forEach(function(p, i){
  var image = p;
  image.addEventListener("mouseover", function(){
	//console.log(this);
	var rect = this.getBoundingClientRect();
//	console.log(rect);
	currentIndex = i;
	updateHighlighter();
  });
});
	
function updateHighlighter(){
	var image = imagesArray[currentIndex];
	
	var rect = image.getBoundingClientRect();
	highlighter.style.opacity = 1;
	highlighter.style.width = rect.width+"px";
	highlighter.style.height = rect.height+"px";
	highlighter.style.top = rect.top+"px";
	highlighter.style.left = rect.left+"px";
	console.log(rect.top+"px", rect.left+"px");
}
	
	window.addEventListener("keydown", function(e){
		console.log(e.keyCode);
		if (e.keyCode == 37) {
			currentIndex--;
		}else if (e.keyCode == 39){
			currentIndex++;
		}
	
		if (currentIndex >= imagesArray.length){
		currentIndex = 0;
		}else if (currentIndex < 0) {
		currentIndex = imagesArray.length -1;
		}
	
  updateHighlighter();
});

//image.addEventListener("mouseover", function(){  
//	var rect = this.getBoundingClientRect();
//	currentIndex = tempI; //supposed to keep track of current highlighted image
//	highlighter.style.opacity = 1;
//	highlighter.style.width = rect.width+"px";
//	highlighter.style.height = rect.height+"px";
//	highlighter.style.top = rect.top+"px";
//	highlighter.style.left = rect.left+"px"; //you can add numbers with strings by using the +
//	});

//var array = [0, 1, 2, 3, 4]; //not defined in js, can include any data type combination, starts at position 0
//
//var i = 0;
//while (i<10){ //similar to if statement, it will run as long as statement is true, used when unsure how many times loop will run
//	console.log("output", i); //this portion of the code ran 10 times, then stopped
//	i = i+1; 
//}
//
//var sum = 0;
//for (var j = 5; j > 0; j--){ //value of j to start from, checker, incriment
//	sum = sum + j;
//}
//console.log("output from for", sum);	